from distutils.core import setup
setup(
    name='pypar',
    packages=['pypar', 'pypar.utils', 'pypar.basics']
)

# python3 setup.py sdist
# python3 setup.py install --prefix ~/.local/
